#ifndef TEACHER_H
#define TEACHER_H

#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>

typedef struct teacher
{
    char *name;
    uint32_t dni;
} teacher_t;

#endif